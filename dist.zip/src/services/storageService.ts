import { supabase } from './supabaseService';

const BUCKET_NAME = 'program-resources';

export const storageService = {
  /**
   * Upload file to Supabase Storage
   */
  async uploadFile(file: File, folder: string = ''): Promise<{url: string, path: string} | null> {
    try {
      // Validate file
      if (!this.validateFile(file)) {
        return null;
      }

      // Generate unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = folder ? `${folder}/${fileName}` : fileName;

      console.log('Uploading file:', { name: file.name, size: file.size, type: file.type, path: filePath });

      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        console.error('Upload error:', error);
        alert(`Failed to upload file: ${error.message}`);
        return null;
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from(BUCKET_NAME)
        .getPublicUrl(data.path);

      console.log('File uploaded successfully:', { url: urlData.publicUrl, path: data.path });

      return {
        url: urlData.publicUrl,
        path: data.path
      };
    } catch (error) {
      console.error('Upload error:', error);
      alert('An error occurred while uploading the file');
      return null;
    }
  },

  /**
   * Download file from Supabase Storage
   */
  async downloadFile(path: string, fileName?: string): Promise<void> {
    try {
      console.log('Downloading file:', { path, fileName });

      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .download(path);

      if (error) {
        console.error('Download error:', error);
        alert(`Failed to download file: ${error.message}`);
        return;
      }

      // Create blob URL and trigger download
      const url = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName || path.split('/').pop() || 'download';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      console.log('File downloaded successfully');
    } catch (error) {
      console.error('Download error:', error);
      alert('An error occurred while downloading the file');
    }
  },

  /**
   * Delete file from Supabase Storage
   */
  async deleteFile(path: string): Promise<boolean> {
    try {
      console.log('Deleting file:', path);

      const { error } = await supabase.storage
        .from(BUCKET_NAME)
        .remove([path]);

      if (error) {
        console.error('Delete error:', error);
        alert(`Failed to delete file: ${error.message}`);
        return false;
      }

      console.log('File deleted successfully');
      return true;
    } catch (error) {
      console.error('Delete error:', error);
      alert('An error occurred while deleting the file');
      return false;
    }
  },

  /**
   * Get signed URL for temporary access
   */
  async getSignedUrl(path: string, expiresIn: number = 3600): Promise<string | null> {
    try {
      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .createSignedUrl(path, expiresIn);

      if (error) {
        console.error('Signed URL error:', error);
        return null;
      }

      return data.signedUrl;
    } catch (error) {
      console.error('Signed URL error:', error);
      return null;
    }
  },

  /**
   * Validate file before upload
   */
  validateFile(file: File): boolean {
    const maxSize = 50 * 1024 * 1024; // 50MB
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'image/jpeg',
      'image/jpg',
      'image/png',
      'image/gif',
      'video/mp4',
      'text/plain',
      'text/csv'
    ];

    // Check file size
    if (file.size > maxSize) {
      alert(`File size must be less than 50MB. Your file is ${(file.size / (1024 * 1024)).toFixed(2)}MB`);
      return false;
    }

    // Check file type
    if (!allowedTypes.includes(file.type)) {
      alert(`File type "${file.type}" is not allowed. Allowed types: PDF, Word, Excel, Images (JPEG, PNG, GIF), MP4 videos, Text, CSV`);
      return false;
    }

    return true;
  },

  /**
   * Get file size in human readable format
   */
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  }
};
